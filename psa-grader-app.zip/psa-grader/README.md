# 🎴 PSA Pokemon Grading Analyzer

A full-stack mobile app (React Native + Node.js) that analyzes Pokemon cards for PSA grading profitability using real eBay sold data, PSA population reports, and Claude AI.

---

## 📁 Project Structure

```
psa-grader/
├── app/          ← React Native (Expo) mobile app
└── backend/      ← Node.js API server (deploy to Railway)
```

---

## 🚀 Part 1: Deploy the Backend

### Step 1 — Get an Anthropic API Key
1. Go to https://console.anthropic.com
2. Sign in → API Keys → Create Key
3. Copy it — you'll need it in Step 3

### Step 2 — Deploy to Railway (free)
1. Go to https://railway.app and sign up (free, no credit card)
2. Click **New Project** → **Deploy from GitHub**
3. If you don't have GitHub: click **Deploy from local** instead and upload the `/backend` folder
4. Railway auto-detects Node.js and runs `node server.js`

### Step 3 — Set your API Key
In your Railway project:
1. Click your service → **Variables** tab
2. Add variable: `ANTHROPIC_API_KEY` = your key from Step 1
3. Railway auto-restarts with the key

### Step 4 — Get your public URL
- Railway gives you a URL like: `https://psa-grader-production.up.railway.app`
- Test it by visiting `https://your-url.up.railway.app/health` — should return `{"status":"ok"}`

---

## 📱 Part 2: Run the Mobile App

### Prerequisites
```bash
node --version   # needs v18+
npm install -g expo-cli
```

### Install & Run
```bash
cd app
npm install
npx expo start
```

Then:
- **iPhone**: Download **Expo Go** from the App Store, scan the QR code
- **Android**: Download **Expo Go** from Play Store, scan the QR code
- **Simulator**: Press `i` for iOS simulator, `a` for Android emulator

### Connect to your backend
1. Open the app → tap **Settings** tab
2. Paste your Railway URL: `https://your-app.up.railway.app`
3. Tap **Save URL** then **Test Connection**
4. You should see ✓ Connected

---

## 🎯 How to Use

### Analyze a Card
1. Tap **Analyze** tab
2. Enter card name, set, card number
3. Enter your buy price and costs
4. Tap **⚡ Analyze Card**
5. The app will:
   - Scrape live eBay UK sold prices for PSA 10, 9, 8, and raw
   - Fetch PSA population report data
   - Ask Claude AI to analyze gem rate and profitability
   - Show you a full grade-by-grade breakdown

### Save to Portfolio
- After analysis, tap **＋ Add to Portfolio**
- View all cards in the **Portfolio** tab
- Tap **↻ Refresh Prices** on any card to get fresh eBay data

---

## ⚙️ API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Check server is running |
| `/analyze` | POST | Full card analysis (eBay + PSA + AI) |
| `/refresh-prices` | POST | Quick eBay price refresh for portfolio |

### Example `/analyze` request:
```json
{
  "cardName": "Charizard",
  "set": "Base Set",
  "num": "4/102",
  "buyPrice": 300,
  "gradeFee": 25,
  "shipping": 13,
  "platFee": 0.13
}
```

---

## 💰 Cost Estimate

| Service | Cost |
|---------|------|
| Railway hobby tier | Free (500hr/month) |
| Anthropic API (Claude Sonnet) | ~£0.01–0.03 per analysis |
| Expo (development) | Free |

---

## 🔧 Troubleshooting

**"Could not connect to backend"**
→ Check your Railway URL in Settings has no trailing slash
→ Visit `your-url/health` in a browser to confirm it's running

**"No eBay prices found"**
→ Try a more specific search term (full card name + set)
→ eBay scraping can be blocked occasionally — results will still show AI estimates

**App won't load on Expo Go**
→ Make sure your phone and computer are on the same WiFi network
→ Try pressing `tunnel` in the Expo CLI instead of `lan`

---

## 📦 Tech Stack

- **App**: React Native, Expo, React Navigation, AsyncStorage
- **Backend**: Node.js, Express, Axios, Cheerio (scraping)
- **AI**: Anthropic Claude Sonnet
- **Hosting**: Railway.app
- **Data**: eBay UK sold listings, PSA Population Report
